
Video > Scaling > Custom
X = 640
Y = 427

Shaders > sharp-bilinear-2x-prescale

1. Core Options:

    Video > Color Correction > OFF

    Video > Interframe Blending > Simple (NOTE: If you don't like the image ghosting, turn it OFF, but you may see flickering elements in games.)


2. Video Settings:

    Integer Scale OFF

    Keep Aspect Ratio ON

    Image Interpolation > Bicubic

    Video Filter > GBA > Filter for overlays > GBAOffset.filt

Thank you to u/1playerinsertcoin and u/mugwomp_93 on Reddit!