Use it with Bilinear filter and, if necessary, with Aspect Ratio ON to avoid any gradient artifacts. It's not always possible to use AR ON, as some games have large overscans or pixel ratios that are far from square (images will look much more distorted than with AR OFF), and in other cases some games could have a better matching scanlines with AR OFF. Just try it with AR ON/OFF and choose what looks best for you in each system.


Shaders > sharp-bilinear-2x-prescale